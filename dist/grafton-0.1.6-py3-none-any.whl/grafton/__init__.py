"""Grafton anonymises data in any input file using an encoding key and informed consent list."""

from grafton.anonymiser import (
    anonymise,
    randomise_number,
)
