"""Flat File GDPR Anonymiser anonymises data in any input file using an encoding key and informed consent list."""

from flat_file_gdpr_anonymiser.__main__ import (
  main,
)
