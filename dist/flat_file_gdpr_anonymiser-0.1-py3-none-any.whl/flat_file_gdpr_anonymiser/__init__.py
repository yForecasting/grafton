"""Flat File GDPR Anonymiser anonymises flat files with an user customisable csv list."""

from flat_file_gdpr_anonymiser.__main__ import (
  main,
)
